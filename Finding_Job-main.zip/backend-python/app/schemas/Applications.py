from pydantic import BaseModel

 