export default Object.freeze({
    MALE: 'male',
    FEMALE: 'female',
})