export default Object.freeze({
    SUBMITTED: 'submitted',
    CANCEL: 'cancel',              
    ACCEPT: 'accept',                   
    REJECTED: 'rejected',           
})